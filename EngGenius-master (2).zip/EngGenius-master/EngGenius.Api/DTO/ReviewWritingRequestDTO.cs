﻿namespace EngGenius.Api.DTO
{
    public class ReviewWritingRequestDTO
    {
        public string Topic { get; set; }
        public string Content { get; set; }
    }
}
