﻿using EngGenius.Domains.Enum;

namespace EngGenius.Domains
{
    public class Level
    {
        public EnumLevel Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
