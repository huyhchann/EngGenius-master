﻿namespace EngGenius.Domains.Enum
{
    public enum EnumPermission
    {
        Free = 1,
        Premium = 2
    }
}
