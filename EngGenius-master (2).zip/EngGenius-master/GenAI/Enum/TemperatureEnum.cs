﻿namespace GenAI.Enum
{
    public enum TemperatureEnum
    {
        Low = 10,
        Medium = 50,
        High = 100,
    }
}
